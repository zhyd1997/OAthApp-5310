const colors = {
  jhipsterBlue: '#3E8ACC',
  transparent: 'rgba(0,0,0,0)',
  error: 'rgba(200, 0, 0, 0.8)',
  white: 'white',
  black: 'black',
  text: '#E0D7E5',
};

export default colors;
