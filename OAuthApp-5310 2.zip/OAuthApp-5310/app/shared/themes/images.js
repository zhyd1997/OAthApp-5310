// leave off @2x/@3x
const images = {
  logoJhipster: require('../images/logo-jhipster.png'),
  toggleDrawerIcon: require('../images/toggle-drawer-icon/toggle-drawer-icon.png'),
};

export default images;
