import { StyleSheet } from 'react-native';

import { ApplicationStyles } from '../../shared/themes';

export default StyleSheet.create({
  ...ApplicationStyles.screen,
});
