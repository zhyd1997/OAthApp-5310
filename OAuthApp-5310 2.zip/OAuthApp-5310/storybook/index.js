import { getStorybookUI, configure } from '@storybook/react-native';
import { View } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import AppConfig from '../app/config/app-config';

// import stories
configure(() => {
  require('./stories');
}, module);

const StorybookUIRoot = AppConfig.debugMode ? getStorybookUI({ asyncStorage: AsyncStorage }) : View;

export default StorybookUIRoot;
