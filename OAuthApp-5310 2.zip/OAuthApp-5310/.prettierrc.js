module.exports = {
  bracketSpacing: false,
  bracketSameLine: true,
  singleQuote: true,
  trailingComma: 'all',
  semi: true,
  printWidth: 140,
  tabWidth: 2,
  bracketSpacing: true,
  useTabs: false,
};
